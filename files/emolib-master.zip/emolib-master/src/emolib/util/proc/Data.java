/*
 * Copyright 1999-2002 Carnegie Mellon University.
 * Portions Copyright 2002 Sun Microsystems, Inc.
 * Portions Copyright 2002 Mitsubishi Electric Research Laboratories.
 * All Rights Reserved.  Use is subject to license terms.
 *
 * See the file "license.terms" for information on usage and
 * redistribution of this file, and for a DISCLAIMER OF ALL
 * WARRANTIES.
 *
 */


package emolib.util.proc;

/**
 * Implements the interface for all Data objects that passes between
 * DataProcessors. Subclass of Data can contain the actual
 * data.
 *
 * @see Data
 */
public interface Data {

}

