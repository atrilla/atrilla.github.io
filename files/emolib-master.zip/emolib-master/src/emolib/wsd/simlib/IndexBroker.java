package emolib.wsd.simlib;

import java.io.IOException ;

import org.apache.lucene.analysis.WhitespaceAnalyzer ;
import org.apache.lucene.queryParser.ParseException ;
import org.apache.lucene.queryParser.QueryParser ;
import org.apache.lucene.search.Hits ;
import org.apache.lucene.search.IndexSearcher ;
import org.apache.lucene.search.Query ;
import org.apache.lucene.search.Searcher ;




/**
 *
 * <p>Title: Java WordNet Similarity</p>
 * <p>Description: Assesses the semantic similarity between a pair of words
 * as described in Seco, N., Veale, T., Hayes, J. (2004) "An Intrinsic Information
 * Content Metric for Semantic Similarity in WordNet". In Proceedings of the
 * European Conference of Artificial Intelligence </p>
 * <p>This Class interfaces with the index files facilitating word and synset
 * lookups </p>
 * <p>Copyright: Nuno Seco Copyright (c) 2004</p>
 * @author Nuno Seco
 * @version 1.0
 */


public class IndexBroker
{
    /**
     * A static constant that represents the field name that
     * holds the offset value of each document.
     */
    public static final String SYNSET = "synset" ;




    /**
     * A static constant that represents the field name that
     * holds the list of words of each document.
     */
    public static final String WORDS = "word" ;




    /**
     * A static constant that represents the field name that
     * holds the list of hypernym offsets of each document. This list also
     * contains the offset of the documented in which it is contained.
     */
    public static final String HYPERNYM = "hypernym" ;




    /**
     * A static constant that represents the field name that
     * holds the information Content value of each document.
     */
    public static final String INFORMATION_CONTENT = "ic" ;


    /**
     * The directory where the broker will look for the Lucene index.
     */
    private String INDEX_DIR = "";




    /**
     * Holds a reference to an instance of a Searcher that
     * allows searches to be conducted in the opened index.
     */
    private Searcher _searcher ;




    /**
     * Holds a reference to an instance of a Parser; a parser
     * parses the query.
     */
    private QueryParser _parser ;




    /**
     * A static reference to an instance of an Index Broker.
     */
    private IndexBroker _instance ;




    /**
     * The Constructor. Has private access to allow the implementation
     * of the singleton design pattern. Points the searcher to the index
     * directory, sets the default field to lookup and the defualt operator
     * that is to be assumed when more than one token is given.
     */
    public IndexBroker ()
    {
        try
        {
            _searcher = new IndexSearcher ( INDEX_DIR ) ;
            _parser = new QueryParser ( WORDS , new WhitespaceAnalyzer () ) ;
            _parser.setDefaultOperator ( QueryParser.AND_OPERATOR ) ;

        }
        catch ( IOException ex )
        {
            ex.printStackTrace () ;
            System.err.println ( "" ) ;
            System.err.println ( "Please place the " + INDEX_DIR + " in the working directory." ) ;
        }
    }

    /**
     * Modified: 1-Feb-2009
     * By:       atrilla
     */
    public IndexBroker (String wnIndexPath)
    {
        INDEX_DIR = wnIndexPath;
        try
        {
            _searcher = new IndexSearcher ( INDEX_DIR ) ;
            _parser = new QueryParser ( WORDS , new WhitespaceAnalyzer () ) ;
            _parser.setDefaultOperator ( QueryParser.AND_OPERATOR ) ;

        }
        catch ( IOException ex )
        {
            ex.printStackTrace () ;
            System.err.println ( "" ) ;
            System.err.println ( "Please place the " + INDEX_DIR + " in the working directory." ) ;
        }
    }


    /**
     * Static method that allows other objects to aquire
     * a reference to an existing broker. If no broker exists
     * than a new one is created.
     * @return IndexBroker
     */
    public IndexBroker getInstance ()
    {
        if ( _instance == null )
        {
            _instance = new IndexBroker () ;
        }

        return _instance ;
    }

    /**
     * Modified: 1-Feb-2009
     * By:       atrilla
     */
    public IndexBroker getInstance (String wnIndexPath)
    {
        if ( _instance == null )
        {
            _instance = new IndexBroker (wnIndexPath) ;
        }

        return _instance ;
    }




    /**
     * Returns the list of documents that fulfill the given query.
     * @param query String  The query to be searched
     * @return Hits  A list of hits
     */
    public Hits getHits ( String query )
    {
        Query q ;
        try
        {
            q = _parser.parse ( query ) ;
            return _searcher.search ( q ) ;
        }
        catch ( ParseException ex )
        {
            ex.printStackTrace () ;
        }
        catch ( IOException ex )
        {
            ex.printStackTrace () ;
        }
        return null ;
    }

}

