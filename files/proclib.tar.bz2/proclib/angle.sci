//
// File    : angle.sci
// Created : 15-Jul-2010
// By      : atrilla
// 
// ProcLib - Signal processing library for Scilab
// 
// Copyright (c) 2010 Alexandre Trilla &
// La Salle - Universitat Ramon Llull
//

function the_angle = angle(cnumber)

	// Calculates the angle described by the input complex number

	the_angle = atan(imag(cnumber),real(cnumber))

endfunction
