//
// File    : h_filter.sci
// Created : 25-Jul-2010
// By      : atrilla
// 
// ProcLib - Signal processing library for Scilab
// 
// Copyright (c) 2010 Alexandre Trilla &
// La Salle - Universitat Ramon Llull
//

function [h,H,ft] = h_filter(G,N,fc1,fc2,fs)

	// Creates a generalised linear-phase FIR filter by windowing (using a rectangular window)
	// the impulse response derived from frequential specs.

	// Normalise frequencies
	wc1 = 2 * %pi * fc1 / fs;
	wc2 = 2 * %pi * fc2 / fs;

	// n always needs to be odd
	// If the desired number of points N is even, h results with N+1 points
	Nhup = floor(N/2);
	n = -Nhup:Nhup;
	h = (wc2 / %pi) * sinc(wc2 * n) - (wc1 / %pi) * sinc(wc1 * n);

	// Final calculations
	// Gain
	h = G * h;

	// 4096 points freq. response
	zs = 8*1024 - length(h);
	haux = [h,zeros(1:zs)];
	H = fft(haux,-1);
	H = H(1:4096);

	// Freq. test points
	ft = (0:4095) / (1024 * 4) * (fs / 2);

endfunction
