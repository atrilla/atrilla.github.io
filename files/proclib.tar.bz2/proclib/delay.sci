//
// File    : delay.sci
// Created : 08-Aug-2010
// By      : atrilla
// 
// ProcLib - Signal processing library for Scilab
// 
// Copyright (c) 2010 Alexandre Trilla &
// La Salle - Universitat Ramon Llull
//

function y = delay(x,T,w,fs)

	// Applies weighted delays to the given signal
	
	if length(T) == length(w) then
		lenX = length(x);
		maxT = max(T);
		maxTN = round(maxT * fs);
		maxY = maxTN + lenX;
		y = zeros(1:maxY);
		for numDelay = 1:length(T)
			delay = round(T(numDelay) * fs);
			wDelay = w(numDelay);
			for sampleX = 1:length(x)
				y(delay + sampleX) = y(delay + sampleX) + wDelay * x(sampleX);
			end
		end
	else
		printf("The lengths of T and w do not match!\n");
	end

endfunction
