function theErr = errStudent(par, x, y)
z = par'*x;
%    y = z > 0;
y_trial = z;

difference = y - y_trial;
lam = 10;
theErr = sum(difference.^2) + lam*sum(log(1 + par.^2));

