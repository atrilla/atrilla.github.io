function theErr = errTikhonov(par, x, y)
z = par'*x;
%    y = z > 0;
y_trial = z;

difference = y - y_trial;
lam = 10;
theErr = sum(difference.^2) + lam*sum(par.^2);

