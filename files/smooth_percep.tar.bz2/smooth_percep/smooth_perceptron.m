%% Smooth ANNs

%% Create Data
numEx = 200;
meanP = 6;
meanN = 2;
x1P = (randn(1,numEx) + meanP)';
x2P = (randn(1,numEx) + meanP)';
x1N = (randn(1,numEx) + meanN)';
x2N = (randn(1,numEx) + meanN)';

figure;
plot(x1P, x2P, 'bo', 'linewidth', 3, 'markersize', 10);
hold on;
plot(x1N, x2N, 'ro', 'linewidth', 3, 'markersize', 10);

% for the discr func
xmin = min(min(x1P), min(x1N)) - 1;
xmax = max(max(x1P), max(x1N)) + 1;
theXs = xmin:0.1:xmax;

% Positive is 1, negative is 0
w_ini=randn(3,1);
w = w_ini;

% Bayes optimal
w(1) = -0.5 * [meanP - meanN; meanP - meanN]' * [meanP + meanN; meanP + meanN];
w(2) = meanP - meanN;
w(3) = meanP - meanN;

% Plot discriminating function
theYs = -w(2)/w(3)*theXs - w(1)/w(3);
plot(theXs, theYs, 'k', 'linewidth', 3);

% Plain
w = fmins('errPlain', w_ini, [],[], [ones(1,2*numEx); [x1N' x1P']; [x2N' x2P']], [-ones(1,numEx) ones(1,numEx)]);
theYs = -w(2)/w(3)*theXs - w(1)/w(3);
plot(theXs, theYs, 'g', 'linewidth', 3);

% Tiknonov
w = fmins('errTikhonov', w_ini, [],[], [ones(1,2*numEx); [x1N' x1P']; [x2N' x2P']], [-ones(1,numEx) ones(1,numEx)]);
theYs = -w(2)/w(3)*theXs - w(1)/w(3);
plot(theXs, theYs, 'c', 'linewidth', 3);

% Lasso
w = fmins('errLasso', w_ini, [],[], [ones(1,2*numEx); [x1N' x1P']; [x2N' x2P']], [-ones(1,numEx) ones(1,numEx)]);
theYs = -w(2)/w(3)*theXs - w(1)/w(3);
plot(theXs, theYs, 'm', 'linewidth', 3);

% Student-t
w = fmins('errStudent', w_ini, [],[], [ones(1,2*numEx); [x1N' x1P']; [x2N' x2P']], [-ones(1,numEx) ones(1,numEx)]);
theYs = -w(2)/w(3)*theXs - w(1)/w(3);
plot(theXs, theYs, 'y', 'linewidth', 3);

hold off;

legend('Positive instances','Negative instances','Bayes optimal', 'Plain (no smooth)','Tikhonov', 'Lasso', 'Student-t');
xlabel('x1');
ylabel('x2');
title('Regularised perceptron');
