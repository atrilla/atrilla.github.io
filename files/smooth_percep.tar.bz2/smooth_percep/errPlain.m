function theErr = errPlain(par, x, y)
z = par'*x;
%    y = z > 0;
y_trial = z;

difference = y - y_trial;
theErr = sum(difference.^2);

